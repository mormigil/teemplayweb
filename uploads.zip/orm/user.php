<?php
class user{
	//relevant variables
	private $id;
	private $username;
	private $password;
	private $level;
	private $description;
	private $votes;
	private $votes_influence;
	private $email;

	//construct new user with all fields
	private function __construct($id, $username, $password, $level, $description, $votes, $votes_influence, $email){
		$this->id = $id;
		$this->username = $username;
		$this->password = $password;
		$this->level = $level;
		$this->description = $description;
		$this->votes = $votes;
		$this->votes_influence = $votes_influence;
		$this->email = $email;
	}

	public static function findByName($name){
		$mysqli = new mysqli("localhost:3306", "root", "", "teemplayweb");
		$query = "SELECT id FROM users WHERE name = ?";
		$prep = $mysqli->prepare($query);
		$prep->bind_param('s', $name);
		$prep->execute();
		$result = $prep->get_result();
		if($result){
			if($result->num_rows == 0){
				return null;
			}
			$id = $result->fetch_row();
			$user = User::findByID($id[0]);
			return $user;
		}
		return null;
	}

	//create new user
	public static function createUser($id, $username, $password, $level, $description, $votes, $votes_influence, $email){
		$mysqli = new mysqli("localhost:3306", "root", "", "teemplayweb");
		$query = "INSERT INTO users (id, name, pass, level, description, votes, votes_influence, email) VALUES(
			?,?,?,?,?,?,?,?)";
		try{
			$prep = $mysqli->prepare($query);
			$prep->bind_param('ssssssss', $id, $username, $password, $level, $description, $votes, $votes_influence, $email);
			if($prep->execute()){
				$id = $mysqli->insert_id;
				return new User($id, $username, $password, $level, $description, $votes, $votes_influence, $email);
			}
			return null;
		}
		catch(PDOException $pdo){
			printf("Errormessage: %s\n", $mysqli->error);
			die("failed to run query");
		}
		
	}

	//given an id return the user
	//useful as a call to return the correct user from other functions
	public static function findByID($id){
		$mysqli = new mysqli("localhost:3306", "root", "", "teemplayweb");
		$query = "SELECT * FROM users WHERE id = ?";
		$prep = $mysqli->prepare($query);
		$prep->bind_param('s', $id);
		$prep->execute();
		$result = $prep->get_result();
		if($mysqli->error){
			printf("Errormessage: %s\n", $mysqli->error);
		}
		if($result){
		if($result->num_rows == 0){
			return null;
		}
		$user_info = $result->fetch_array();
		return new User($user_info['id'], $user_info['name'], $user_info['pass'], $user_info['level'],
			$user_info['description'], $user_info['votes'], $user_info['votes_influence'], $user_info['email']);
		}
		return null;
	}

	//general update for whatever fields were input
	public function update(){
		$mysqli = new mysqli("localhost:3306", "root", "", "nu");
		$query = "UPDATE users SET username = ?, password = ?, level = ?, description = ?, votes = ?,  votes_influence = ?, email = ? WHERE id = ?";
		$prep = $mysqli->prepare($query);
		$prep->bind_param('ssssssss', $this->username, $this->password, $this->level, $this->description, $this->votes, $this->votes_influence, $this->email, $this->id);
		$prep->execute();
		$result = $prep->get_result();
		if($mysqli->error){
			printf("Errormessage: %s\n", $mysqli->error);
		}
		return $result;
	}

	//read

	public function getJSON(){
		$json_rep = array();
		$json_rep['id'] = $this->id;
		$json_rep['username'] = $this->username;
		$json_rep['password'] = $this->password;
		$json_rep['level'] = $this->level;
		$json_rep['description'] = $this->description;
		$json_rep['votes'] = $this->votes;
		$json_rep['votes_influence'] = $this->votes_influence;
		$json_rep['email'] = $this->email;
		return $json_rep;
	}

	public function getID(){
		return ($this->id);
	}

	public function getPass(){
		return ($this->password);
	}

}
?>