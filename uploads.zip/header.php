<div id = "header">
	<a href = "#"><img id = "logoimg" src = "http://localhost/teemplayweb/transparlogo.png" alt = "logo"></img></a>
	<ul id = "nav-menu">
		<a class = "nav_buttons" href = "http://localhost/teemplayweb/inspiration_viewing.php"><li>Inspire</li></a>
		<a class = "nav_buttons" href = "http://localhost/teemplayweb/idea_viewing.php"><li>Imagine</li></a>
		<a class = "nav_buttons" href = "http://localhost/teemplayweb/project_viewing.php"><li>Design</li></a>
		<a class = "nav_buttons" href = ""><li>Play</li></a>
	</ul>
	<div id = "userinfo"></div>
</div>